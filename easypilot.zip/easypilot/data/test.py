from logging import exception
from turtle import undobufferentries
from xml.dom import NotFoundErr
import numpy as np
import cv2 as cv
from win32api import GetKeyState
from win32con import VK_CAPITAL
import matplotlib.pyplot as plt
import time, os, PIL, pyvjoy, sys
from PIL import Image, ImageGrab
from numpy import array, absolute, max, uint8, zeros_like, arange, arctan2, pi, sqrt, float32, sum, dstack, argmax, concatenate, mean, linspace, polyfit, dstack, transpose, vstack, flipud, hstack, int_

def show_image_on_plot(image):
    # this function will show captured image to a plot so we can see it in cartesian
    plt.xticks(np.arange(0, 2000, 50.0))
    plt.yticks(np.arange(0, 2000, 50.0))
    plt.imshow(image)
    plt.show()

def warp2top_image(img):
    img_gray = cv.cvtColor(img, cv.COLOR_RGB2GRAY)

    image_size = (img.shape[1], img.shape[0])
    x = img.shape[1]
    y = img.shape[0]

    source_points = np.float32([
    [0, y],
    [(0.5 * x) - (x*0.47), 0.55*y],
    [(0.5 * x) + (x*0.47), 0.55*y],
    [x, y]
    ])
    
    destination_points = [
    [x*0.5 - (x*0.05), y],
    [0, 0],
    [x, 0],
    [x*0.5 + (x*0.05), y]
    ]
    dest2_points = np.float32(destination_points)

    perspective_transform = cv.getPerspectiveTransform(source_points, dest2_points)

    warped_img = cv.warpPerspective(img_gray, perspective_transform, image_size, flags=cv.INTER_LINEAR)
    result_img = cv.resize(warped_img, (480, 270), interpolation=cv.INTER_AREA)

    return result_img

def warp2lane_us(img):

    image_size = (img.shape[1], img.shape[0])
    x = img.shape[1]
    y = img.shape[0]

    source_points = np.float32([
    [x*0.35, y],
    [x*0.35, 0],
    [x - (x*0.35), 0],
    [x - (x*0.35), y]
    ])

    destination_points = np.float32([
    [x*0.01, y],
    [x*0.01, 0],
    [x - (x*0.01), 0],
    [x - (x*0.01), y]
    ])
   

    perspective_transform = cv.getPerspectiveTransform(source_points, destination_points)

    warped_img = cv.warpPerspective(img, perspective_transform, image_size, flags=cv.INTER_LINEAR)

    return warped_img

def get_bin_lane(img, left_fitx, right_fitx, offset):

    # Generate x and y values
    ploty = np.linspace(0, img.shape[0]-1, img.shape[0] )

    # Create an image to draw the lines on
    warp_zero = np.zeros_like(img).astype(np.uint8)
    color_warp = np.dstack((warp_zero, warp_zero, warp_zero))

    # Recast x and y for cv2.fillPoly()
    pts_left = np.array([np.transpose(np.vstack([left_fitx - offset, ploty]))])
    pts_right = np.array([np.flipud(np.transpose(np.vstack([right_fitx + offset, ploty])))])
    pts = np.hstack((pts_left, pts_right))

    # Draw the lane 
    cv.fillPoly(color_warp, np.int_([pts]), (255,255,255))
    color_warp = cv.cvtColor(color_warp, cv.COLOR_RGB2GRAY)

    return color_warp

def binary_pipeline_us(img, left_fit, right_fit, prev_intensity, left_fitx, right_fitx, lane_detected):

    blur_img = cv.blur(img, (3,3))
    resized_blur = cv.resize(cv.blur(img, (4, 4)),(int(blur_img.shape[1]/4), int(blur_img.shape[0]/4)), interpolation=cv.INTER_AREA)

    img_ad = cv.adaptiveThreshold(blur_img, 255, cv.ADAPTIVE_THRESH_GAUSSIAN_C,cv.THRESH_BINARY, 13, -4)
    img_ad = cv.resize(img_ad,(img.shape[1], img.shape[0]), interpolation=cv.INTER_AREA)
    
    x = blur_img.shape[1]
    y = blur_img.shape[0]

    #combiners
    result_img = img_ad

    if lane_detected == True:

        offset = 12

        bin_seg = get_bin_lane(result_img, left_fitx, right_fitx, -1*(offset))
        bin_seg2 = get_bin_lane(result_img, left_fitx, right_fitx, offset)

        bin_seg = np.bitwise_not(bin_seg)
        lanes = np.bitwise_and(bin_seg2, bin_seg)

        result_img = np.bitwise_and(lanes, result_img)
    else:
        
        bin_points = [
        [x*0.42, y],
        [x*0.42, 0],
        [x - (x*0.42), 0],
        [x - (x*0.42), y]
        ]

        poly = np.array([bin_points])
        lane = np.zeros((y,x), np.uint8)
        lane = cv.fillPoly(lane, np.int32([poly]), 255)

        result_img = np.bitwise_and(lane, result_img)
    
    bin_points = [
    [x*0.5 - (x*0.05)+20, y],
    [20, 0],
    [x-20, 0],
    [x*0.5 + (x*0.05)-20, y]
    ]

    poly = np.array([bin_points])
    color_warp = np.zeros((y,x), np.uint8)
    color_warp = cv.fillPoly(color_warp, np.int32([poly]), 255)
    result_img = np.bitwise_and(color_warp, result_img)
    show(result_img, "binary")


    return result_img, color_warp

def track_lanes_update(binary_warped, left_fit,right_fit, notfound, right_pxls, left_pxls,a,b,prev_left_fit,prev_right_fit):

    nonzero = binary_warped.nonzero()
    nonzeroy = np.array(nonzero[0])
    nonzerox = np.array(nonzero[1])
    margin = 6
    left_lane_inds = ((nonzerox > (left_fit[0]*(nonzeroy**2) + left_fit[1]*nonzeroy + left_fit[2] - margin)) & (nonzerox < (left_fit[0]*(nonzeroy**2) + left_fit[1]*nonzeroy + left_fit[2] + margin))) 
    right_lane_inds = ((nonzerox > (right_fit[0]*(nonzeroy**2) + right_fit[1]*nonzeroy + right_fit[2] - margin)) & (nonzerox < (right_fit[0]*(nonzeroy**2) + right_fit[1]*nonzeroy + right_fit[2] + margin)))  

    # Again, extract left and right line pixel positions
    leftx = nonzerox[left_lane_inds]
    lefty = nonzeroy[left_lane_inds] 
    rightx = nonzerox[right_lane_inds]
    righty = nonzeroy[right_lane_inds]
    # Fit a second order polynomial to each
    left_fit = np.polyfit(lefty, leftx, 2)
    right_fit = np.polyfit(righty, rightx, 2)
    # Generate x and y values for plotting
    ploty = np.linspace(0, binary_warped.shape[0]-1, binary_warped.shape[0] )
    left_fitx = left_fit[0]*ploty**2 + left_fit[1]*ploty + left_fit[2]
    right_fitx = right_fit[0]*ploty**2 + right_fit[1]*ploty + right_fit[2]
    if 0:
        right_to_left = right_pxls/left_pxls
        a = ((right_fit[0]*right_to_left + left_fit[0])/(right_to_left+1)+a)/2
        b = ((right_fit[1]*right_to_left + left_fit[1])/(right_to_left+1)+b)/2
        c = (right_fit[2]*right_to_left + left_fit[2])/(right_to_left+1)
        left_fit = [a,b,c-20]
        right_fit = [a,b,c+20]
    #elif prev_left_fit != "None" or prev_right_fit != "None":
    #    left_fit = [(prev_left_fit[0]+left_fit[0])/2, (prev_left_fit[1]+left_fit[1])/2, left_fit[2]]
    #    right_fit = [(prev_right_fit[0]+right_fit[0])/2, (prev_right_fit[1]+right_fit[1])/2, right_fit[2]]
    #except:

    # give the the other lane line when a line is not found
    if notfound == 2:
        left_fit = [right_fit[0], right_fit[1], right_fit[2]-40]
    if notfound == 1:
        right_fit = [left_fit[0], left_fit[1], left_fit[2]+40]
    if notfound == 3:
        raise ValueError('"no lanes detected" error404: if notfound == 3: raise ValueError')


    return left_fit,right_fit,leftx,lefty,rightx,righty,a,b

def track_lanes_initialize(binary_warped):

    histogram = np.sum(binary_warped[int(binary_warped.shape[0]/2):,:], axis=0)
    
    # Create an output image to draw on and  visualize the result
    out_img = np.dstack((binary_warped, binary_warped, binary_warped))*255
    
    # we need max for each half of the histogram. the example above shows how
    # things could be complicated if didn't split the image in half 
    # before taking the top 2 maxes
    midpoint = int(histogram.shape[0]/2)
    leftx_base = np.argmax(histogram[:midpoint])
    rightx_base = np.argmax(histogram[midpoint:]) + midpoint
    
    # Choose the number of sliding windows
    # this will throw an error in the height if it doesn't evenly divide the img height
    nwindows = 5
    # Set height of windows
    window_height = int(binary_warped.shape[0]/nwindows)
    
    # Identify the x and y positions of all nonzero pixels in the image
    nonzero = binary_warped.nonzero()
    nonzeroy = np.array(nonzero[0])
    nonzerox = np.array(nonzero[1])
    
    # Current positions to be updated for each window
    leftx_current = leftx_base
    rightx_current = rightx_base
    
    # Set the width of the windows +/- margin
    margin = 10
    # Set minimum number of pixels found to recenter window
    laneminpix = 30
    minpix = laneminpix/(nwindows*margin)
    # Create empty lists to receive left and right lane pixel indices
    left_lane_inds = []
    right_lane_inds = []

    left_pxls = 0
    right_pxls = 0
    notfound = 3
    
    # Step through the windows one by one
    for window in range(nwindows):
        # Identify window boundaries in x and y (and right and left)
        win_y_low = int(binary_warped.shape[0] - (window+1)*window_height)
        win_y_high = int(binary_warped.shape[0] - window*window_height)
        win_xleft_low = leftx_current - margin
        win_xleft_high = leftx_current + margin
        win_xright_low = rightx_current - margin
        win_xright_high = rightx_current + margin
        # Draw the windows on the visualization image
        cv.rectangle(out_img,(win_xleft_low,win_y_low),(win_xleft_high,win_y_high),(0,255,0), 3) 
        cv.rectangle(out_img,(win_xright_low,win_y_low),(win_xright_high,win_y_high),(0,255,0), 3) 
        # Identify the nonzero pixels in x and y within the window
        good_left_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) & (nonzerox >= win_xleft_low) & (nonzerox < win_xleft_high)).nonzero()[0]
        good_right_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) & (nonzerox >= win_xright_low) & (nonzerox < win_xright_high)).nonzero()[0]
        # Append these indices to the lists
        left_lane_inds.append(good_left_inds)
        right_lane_inds.append(good_right_inds)
        # If you found > minpix pixels, recenter next window on their mean position
        if len(good_left_inds) > minpix:
            leftx_current = int(np.mean(nonzerox[good_left_inds]))
        if len(good_right_inds) > minpix:        
            rightx_current = int(np.mean(nonzerox[good_right_inds]))

        left_pxls += len(good_left_inds)
        right_pxls += len(good_right_inds)

            
    # Concatenate the arrays of indices
    left_lane_inds = np.concatenate(left_lane_inds)
    right_lane_inds = np.concatenate(right_lane_inds)

    # Extract left and right line pixel positions
    leftx = nonzerox[left_lane_inds]
    lefty = nonzeroy[left_lane_inds] 
    rightx = nonzerox[right_lane_inds]
    righty = nonzeroy[right_lane_inds] 

    # Fit a second order polynomial to each
    left_fit = np.polyfit(lefty, leftx, 2)
    right_fit = np.polyfit(righty, rightx, 2)
    
    # Generate x and y values for plotting
    ploty = np.linspace(0, binary_warped.shape[0]-1, binary_warped.shape[0] )
    left_fitx = left_fit[0]*ploty**2 + left_fit[1]*ploty + left_fit[2]
    right_fitx = right_fit[0]*ploty**2 + right_fit[1]*ploty + right_fit[2]

    nonzero = binary_warped.nonzero()
    nonzeroy = np.array(nonzero[0])
    nonzerox = np.array(nonzero[1])
    left_lane_inds = ((nonzerox > (left_fit[0]*(nonzeroy**2) + left_fit[1]*nonzeroy + left_fit[2] - margin)) & (nonzerox < (left_fit[0]*(nonzeroy**2) + left_fit[1]*nonzeroy + left_fit[2] + margin))) 
    right_lane_inds = ((nonzerox > (right_fit[0]*(nonzeroy**2) + right_fit[1]*nonzeroy + right_fit[2] - margin)) & (nonzerox < (right_fit[0]*(nonzeroy**2) + right_fit[1]*nonzeroy + right_fit[2] + margin)))  

    try:
        laneminpix = laneminpix*4

        # Again, extract left and right line pixel positions
        leftx = nonzerox[left_lane_inds]
        lefty = nonzeroy[left_lane_inds] 
        rightx = nonzerox[right_lane_inds]
        righty = nonzeroy[right_lane_inds]
        # Fit a second order polynomial to each
        left_fit = np.polyfit(lefty, leftx, 2)
        right_fit = np.polyfit(righty, rightx, 2)

        if left_pxls < laneminpix and right_pxls < laneminpix:
            notfound = 3
        elif right_pxls < laneminpix:
            notfound = 1
        elif left_pxls < laneminpix :
            notfound = 2
        else:
            notfound = 0

        return left_fit,right_fit,notfound,right_pxls,left_pxls,minpix

    except:
        raise ValueError('"no lanes detected" error405: no lane pixels')

def lane_fill_poly(binary_warped,undist,left_fit,right_fit, color):

    # Generate x and y values
    ploty = np.linspace(0, binary_warped.shape[0]-1, binary_warped.shape[0] )
    left_fitx = get_val(ploty,left_fit)
    right_fitx = get_val(ploty,right_fit)
    
    # Create an image to draw the lines on
    warp_zero = np.zeros_like(binary_warped).astype(np.uint8)
    color_warp = np.dstack((warp_zero, warp_zero, warp_zero))

    # Recast x and y for cv2.fillPoly()
    pts_left = np.array([np.transpose(np.vstack([left_fitx, ploty]))])
    pts_right = np.array([np.flipud(np.transpose(np.vstack([right_fitx, ploty])))])
    pts = np.hstack((pts_left, pts_right))

    # Draw the lane 
    cv.fillPoly(color_warp, np.int_([pts]), color)

    # Warp using inverse perspective transform
    newwarp = cv.resize(color_warp, (undist.shape[0], undist.shape[1]), interpolation = cv.INTER_AREA)
    undist = cv.resize(newwarp, (undist.shape[0], undist.shape[1]), interpolation = cv.INTER_AREA)
    # overlay
    #newwarp = cv.cvtColor(newwarp, cv.COLOR_BGR2RGB)
    result = cv.addWeighted(undist, 1, newwarp, 0.3, 0)
        
    return result, left_fit, right_fit, left_fitx, right_fitx

def measure_curve(binary_warped,left_fit,right_fit):
        
    # generate y values 
    ploty = np.linspace(0, binary_warped.shape[0]-1, binary_warped.shape[0] )
    
    # measure radius at the maximum y value, or bottom of the image
    # this is closest to the car 
    y_eval = np.max(ploty)
    
    # coversion rates for pixels to metric
    # THIS RATE CAN CHANGE GIVEN THE RESOLUTION OF THE CAMERA!!!!!
    # BE SURE TO CHANGE THIS IF USING DIFFERENT SIZE IMAGES!!!
    ym_per_pix = 30/720 # meters per pixel in y dimension
    xm_per_pix = 3.7/700 # meters per pixel in x dimension
   
    # x positions lanes
    leftx = get_val(ploty,left_fit)
    rightx = get_val(ploty,right_fit)

    # fit polynomials in metric 
    left_fit_cr = np.polyfit(ploty*ym_per_pix, leftx*xm_per_pix, 2)
    right_fit_cr = np.polyfit(ploty*ym_per_pix, rightx*xm_per_pix, 2)
    
    # calculate radii in metric from radius of curvature formula
    left_curverad = ((1 + (2*left_fit_cr[0]*y_eval*ym_per_pix + left_fit_cr[1])**2)**1.5) / np.absolute(2*left_fit_cr[0])
    right_curverad = ((1 + (2*right_fit_cr[0]*y_eval*ym_per_pix + right_fit_cr[1])**2)**1.5) / np.absolute(2*right_fit_cr[0])
    
    # averaged radius of curvature of left and right in real world space
    # should represent approximately the center of the road
    curve_rad = round((left_curverad + right_curverad)/2)
    curve_rad = round(1/curve_rad,4)
    
    return curve_rad

def unsure_main(w_img, left_fit, right_fit, r_intensity, a, b, left_fitx, right_fitx, lane_detected,prev_left_fit,prev_right_fit):
    
    #
    # us_main
    #


    bin_img, image = binary_pipeline_us(w_img, left_fit, right_fit, r_intensity, left_fitx, right_fitx, lane_detected)

    left_fit,right_fit, notfound,right_pxls,left_pxls,minpix = track_lanes_initialize(bin_img)
    left_fit,right_fit,leftx,lefty,rightx,righty,a,b = track_lanes_update(bin_img, left_fit,right_fit, notfound, right_pxls, left_pxls,a,b,prev_left_fit,prev_right_fit)

    return w_img, left_fit, right_fit, image, r_intensity,a,b


    #
    # us_main
    #


def get_val(y,poly_coeff):
    return poly_coeff[0]*y**2+poly_coeff[1]*y+poly_coeff[2]

def vehicle_offset_us(left_fit, right_fit, img):

    xm_per_pix = 2997/154000
    image_center = img.shape[1]/2

    left_low = get_val(img.shape[0],left_fit)
    right_low = get_val(img.shape[0],right_fit)
    right_high = get_val(0,right_fit)
    left_high = get_val(0,left_fit)
    right_mid = get_val(int(img.shape[0]/2),right_fit)
    left_mid = get_val(int(img.shape[0]/2),left_fit)

    return left_high,right_high,left_mid,right_mid,right_low,left_low

def cal(img):
    f, (ax1, ax2) = plt.subplots(1, 2, figsize=(24, 9))
    f.tight_layout()


    image_size = (img.shape[1], img.shape[0])
    x = img.shape[1]
    y = img.shape[0]

    source_points = np.float32([
    [x*0.35, y],
    [x*0.35, 0],
    [x - (x*0.35), 0],
    [x - (x*0.35), y]
    ])

    destination_points = np.float32([
    [x*0.01, y],
    [x*0.01, 0],
    [x - (x*0.01), 0],
    [x - (x*0.01), y]
    ])

    perspective_transform = cv.getPerspectiveTransform(source_points, destination_points)
    warped_img = cv.warpPerspective(img, perspective_transform, image_size, flags=cv.INTER_LINEAR)

    source_points2 = np.int32([
    [x*0.35, y],
    [x*0.35, 0],
    [x - (x*0.35), 0],
    [x - (x*0.35), y]
    ])

    draw_poly = cv.polylines(img,[source_points2],True,(255,0,0), 5)

    ax1.imshow(draw_poly)
    ax1.set_title('Source', fontsize=40)
    ax2.imshow(warped_img, cmap='gray')
    ax2.set_title('Destination', fontsize=40)
    plt.subplots_adjust(left=0., right=1, top=0.9, bottom=0.)
    plt.tight_layout()
    plt.show()
    show_image_on_plot(warped_img)

def show(img, message):
    cv.imshow(message, img)
    cv.waitKey(1)
    #cv.imwrite(str(message) + ".png", img)

def steer(steering_angle, yvector):
    try:
        j = pyvjoy.VJoyDevice(1)

        j.data.wAxisX = steering_angle
        j.data.wAxisY = yvector
        j.update()

    except:
        print("could not connect to vjoy")
        time.sleep(0.02)
        steer(steering_angle, yvector)

#var difiner
r_intensity = 100
lane_detected = False
left_fit = "None"
right_fit = "None"
notfound = 0
prev_fitcurve = 0
prev_prev_fitcurve = 0
prev_offset = 0
prev_prev_offset = 0
prev_curve = 0
prev_prev_curve = 0
prev_prev_prev_curve = 0
prev_angle = 16384
speed = 0
prev_speed = 0
prev_left_fit = "None"
prev_right_fit = "None"
from dev_config import sensitivity
from dev_config import dev
from dev_config import show_output
from dev_config import color
time.sleep(3)
a = 0
b = 0
left_fitx = "None"
right_fitx = "None"
while 1:
    try:
        # img grabber
        start_time = time.time()
        screenshot = ImageGrab.grab()
        keystate = GetKeyState(VK_CAPITAL)
        img = np.array(screenshot)
        img = cv.cvtColor(img, cv.COLOR_RGB2BGR)
        img = cv.resize(img, (1920, 1080), interpolation=cv.INTER_AREA)

        # warper
        w_img= warp2top_image(img)

        #cal(w_img)
        
        bin_img, left_fit, right_fit, image, r_intensity, a, b = unsure_main(w_img, left_fit, right_fit, r_intensity, a, b, left_fitx, right_fitx, lane_detected,prev_left_fit,prev_right_fit)

        # lane position
        left_high,right_high,left_mid,right_mid,right_low,left_low = vehicle_offset_us(left_fit, right_fit, w_img)

        max_dis = max([abs(left_high-right_high),abs(left_mid-right_mid),abs(left_low-right_low)])
        if max_dis >= 70:
            lane_detected = False
        
        lane_botum_center = (left_low+right_low)/2
        lane_upper_center = (left_high+right_high)/2
        lane_mid_center = (left_mid+right_mid)/2

        curve = (lane_botum_center+lane_upper_center)/2-lane_mid_center
        curve = (curve + prev_curve + prev_prev_curve + prev_prev_prev_curve)/4

        offset = w_img.shape[1]/2 - lane_botum_center
        speed = ((offset - prev_offset) + prev_speed)/2

        prev_offset = offset
        prev_prev_offset = prev_offset
        prev_curve = curve
        prev_prev_curve = prev_curve
        prev_prev_prev_curve = prev_prev_curve
        prev_speed = speed

        # gui
        line_image, left_fit, right_fit, left_fitx, right_fitx = lane_fill_poly(bin_img, bin_img, left_fit, right_fit, color)
        line_image = cv.resize(line_image, (int(w_img.shape[1]), int(w_img.shape[0])))
        w_img = cv.cvtColor(w_img, cv.COLOR_BGR2RGB)
        added_img = cv.addWeighted(w_img, 1, line_image, 0.8, 0)

        #steer
        proportional = (offset*-160)*sensitivity
        derivitive = (speed*-310)*sensitivity
        angle = 16384 + proportional + derivitive + (curve*240)
        steering_angle = (angle+prev_angle)/2

        if keystate == True:
            steer(int(steering_angle), 16384)
        else:
            steer(16384, 16384)

        prev_angle = angle


        #show result

        #end code
        lane_detected = True
        calculate_t = time.time() - start_time
        fps = 1/calculate_t
        prev_left_fit = left_fit
        prev_right_fit = right_fit

        #printer
        if dev == True:
            print("###############")
            print("fps:", fps)
            print("notfound:", notfound)
            print("curve:", curve)
            print("offset:", offset)
            print("angle:", steering_angle)


    except Exception as e:
        lane_detected = False
        if e != '"no lanes detected" error405: no lane pixels':
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print("!!!ERR!!! error on line", exc_tb.tb_lineno,"in document", fname, "    error:", ('"'+str(e)+'"'))
        else:
            continue

