dev = True
show_output = True
sensitivity = 1 #do not change if you don't know what you're doing (!nerds only!)
color = (255,0,80) #color of lane in format: (blue,green,red)
